mod_book和myswitch项目里没有提交历史，如果查看项目的提交历史，请使用以下命令自行Clone：

    git clone https://github.com/seven1240/mod_book.git
    git clone https://github.com/seven1240/myswitch.git
