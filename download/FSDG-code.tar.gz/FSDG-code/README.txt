全部文件都使用UTF-8编码。代码文件都使用的UNIX格式的换行符，如果你在Windows下查看，请使用除记录本以外的一个真正的文本编辑器如Sublime Text、Notepad++、Editplus、UltraEdit等。

有任何问题，请访问 http://book.dujinfang.com 或加微信 FreeSWITCH-CN 获取更多信息。

