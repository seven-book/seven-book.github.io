session.answer();
session.sleep(1000);
session.streamFile("/tmp/hello-js.wav");
session.hangup();
